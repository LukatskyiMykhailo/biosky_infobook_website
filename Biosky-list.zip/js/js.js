let lang = localStorage.getItem('lang');

if( lang == null){
	lang = 'ua';
}

showLang();

function showLang(){
	if( lang == 'ua' ){
		$(".ua").addClass('active');
		$(".ru").removeClass('active');
		$(".ua-js").show();
		$(".ru-js").hide();
	}
	if( lang == 'ru' ){
		$(".ru").addClass('active');
		$(".ua").removeClass('active');
		$(".ru-js").show();
		$(".ua-js").hide();
	}
}

$(document).ready(function(){
	$(".ua").on("click", function (e) {
		$(".ua").addClass('active');
		$(".ru").removeClass('active');
		
		localStorage.setItem('lang', 'ua');
		lang = 'ua';
		
		showLang();
	});
	
	$(".ru").on("click", function (e) {
		$(".ru").addClass('active');
		$(".ua").removeClass('active');
		
		localStorage.setItem('lang', 'ru');
		lang = 'ru';
		
		showLang();
	});
	
	$(".goods .item .btn").on("click", function (e) {
		$(this).parents('.item').find('.ingridient').toggle();
		
	});
});



































